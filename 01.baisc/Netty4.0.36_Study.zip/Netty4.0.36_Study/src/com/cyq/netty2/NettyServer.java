package com.cyq.netty2;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;

public class NettyServer {

	private int port;

	public NettyServer(int port) {
		this.port = port;
		bind();
	}

	private void bind() {
		/**用于分配处理业务线程的线程组个数 */
		//boss 默认大小  int BIZGROUPSIZE = Runtime.getRuntime().availableProcessors()*2;	
		EventLoopGroup boss = new NioEventLoopGroup();
		EventLoopGroup worker = new NioEventLoopGroup();
		try {
			ServerBootstrap bootstrap = new ServerBootstrap();
			bootstrap.group(boss, worker);
			bootstrap.channel(NioServerSocketChannel.class);
			bootstrap.option(ChannelOption.SO_BACKLOG, 1024); //连接数
			bootstrap.option(ChannelOption.TCP_NODELAY, true);  //不延迟，消息立即发送
			bootstrap.childOption(ChannelOption.SO_REUSEADDR, true);   //重用地址
			//bootstrap.childOption(ChannelOption.SO_KEEPALIVE, false); //true长连接
			bootstrap.childHandler(new ChannelInitializer<SocketChannel>() {
				int i=0;
				@Override
				protected void initChannel(SocketChannel socketChannel)	throws Exception {
					i++;
					ChannelPipeline p = socketChannel.pipeline();
					p.addLast(new NettyServerHandler(i));
				}
			});
			ChannelFuture future = bootstrap.bind(port).sync();
			if (future.isSuccess()) {
				System.out.println("启动Netty服务成功，端口号：" + this.port);
			}
			// 关闭连接		
			future.channel().closeFuture().sync();

		} catch (Exception e) {
			System.out.println("启动Netty服务异常，异常信息：" + e.getMessage());
			e.printStackTrace();
		} finally {
			boss.shutdownGracefully();
			worker.shutdownGracefully();
		}
	}

	public static void main(String[] args) throws InterruptedException {

		new NettyServer(9999);
	}
}