package com.cyq.netty2;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.nio.charset.Charset;

public class NettyServerHandler extends ChannelInboundHandlerAdapter {
	int i;
	public NettyServerHandler(int i) {
		this.i=i;
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) {

		ByteBuf buf = (ByteBuf) msg;
		String recieved = getMessage(buf);
		System.out.println(recieved);
		System.out.println("服务器接收到消息：" + i);
		ctx.close();
	}

	/*
	 * 从ByteBuf中获取信息 使用UTF-8编码返回
	 */
	private String getMessage(ByteBuf buf) {

		byte[] con = new byte[buf.readableBytes()];
		buf.readBytes(con);
		return new String(con, Charset.forName("utf-8"));
	}
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx,
			Throwable cause) throws Exception {
		ctx.close();
	}
}
