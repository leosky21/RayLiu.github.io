package com.cyq.netty2;

import java.net.Socket;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.OutputStreamWriter;

/**多线程客户端
 * @author cyq
 *
 */
public class Client {

	public static void main(String[] args) {

		for(int i=0;i<10000;i++){
			new Thread(new ClientThread()).start();
		}
	}
}

class ClientThread implements Runnable{

	@Override
	public void run() {

		String server = "127.0.0.1"; 
		int port = 9999;
		try {
			Socket sock = new Socket(server, port);
			sock.setTcpNoDelay(true);
			FileInputStream fileIn = new FileInputStream("C:\\Users\\bh\\Desktop\\新建文本文档.txt");
			InputStreamReader reader=new InputStreamReader(fileIn, "utf-8");
			sendMsg(sock, reader);
			reader.close();
			fileIn.close();
			sock.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

	/**发送消息
	 * @param sock
	 * @param reader
	 * @throws IOException
	 */
	private void sendMsg(Socket sock, InputStreamReader reader) 
			throws IOException {
		OutputStream sockOut = sock.getOutputStream();
		BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(sockOut, "utf-8"));
		int bytesRead;                      // Number of bytes read
		char[] buffer = new char[1024];  // Byte buffer
		while ((bytesRead = reader.read(buffer)) != -1) {
			writer.write(buffer, 0, bytesRead);
		}
		writer.close();
	}

}